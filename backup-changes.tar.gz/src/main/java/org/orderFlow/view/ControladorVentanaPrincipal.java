package org.orderFlow.view;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ControladorVentanaPrincipal {
    @FXML
    private void gestionarMozos(ActionEvent event) {
        // Aquí abre la ventana de gestión de mozos
    }

    @FXML
    private void gestionarPedidos(ActionEvent event) {
        // Aquí abre la ventana de gestión de pedidos
    }
}
